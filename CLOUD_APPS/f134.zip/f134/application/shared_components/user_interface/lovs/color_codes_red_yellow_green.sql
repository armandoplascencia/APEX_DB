prompt --application/shared_components/user_interface/lovs/color_codes_red_yellow_green
begin
--   Manifest
--     COLOR CODES RED, YELLOW, GREEN
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9008156634332785
,p_default_application_id=>134
,p_default_id_offset=>172493832712964115
,p_default_owner=>'MISO'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(9031293515707940313)
,p_lov_name=>'COLOR CODES RED, YELLOW, GREEN'
,p_lov_query=>'.'||wwv_flow_api.id(9031293515707940313)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9031293716625940328)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Red'
,p_lov_return_value=>'Red'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9031293935770940339)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Yellow'
,p_lov_return_value=>'Yellow'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9031294129389940339)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Green'
,p_lov_return_value=>'Green'
);
wwv_flow_api.component_end;
end;
/
