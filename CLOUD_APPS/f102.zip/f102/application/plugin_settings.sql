prompt --application/plugin_settings
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9008156634332785
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'MISO'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47194950186673921)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47195236683673922)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_JET'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47195565649673923)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attribute_01=>'IG'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47195831780673923)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_RICH_TEXT_EDITOR'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47196160754673923)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47196457314673923)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47196792440673923)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47197015115673924)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(47197348947673924)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_CSS_CALENDAR'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(77563433695820976)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'PLUGIN_DE.DANIELH.DROPZONE2'
,p_attribute_01=>'Drop files here or click to upload.'
,p_attribute_02=>'Your browser does not support drag''n''drop file uploads.'
,p_attribute_03=>'File is too big ({{filesize}}MiB). Max filesize: {{maxFilesize}}MiB.'
,p_attribute_04=>'You can not upload more than {{maxFiles}} files.'
,p_attribute_05=>'Remove file'
,p_attribute_06=>'Cancel upload'
,p_attribute_07=>'Are you sure you want to cancel this upload?'
,p_attribute_08=>'You can not upload files of this type.'
,p_attribute_09=>'1048576'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(97088683511524404)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'PLUGIN_HR.BILOG.MGORICKI.ADVANCED_SLIDER'
,p_attribute_01=>'advanced_slider/css/'
,p_attribute_02=>'advanced_slider/js/'
);
wwv_flow_api.create_plugin_setting(
 p_id=>wwv_flow_api.id(97335005029243563)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'PLUGIN_PRETIUS_APEX_RANGE_DATE'
,p_attribute_03=>'2'
,p_attribute_04=>'t-Button t-Button--small'
,p_attribute_05=>'t-Button--hot'
,p_attribute_06=>'t-Cancel'
);
wwv_flow_api.component_end;
end;
/
